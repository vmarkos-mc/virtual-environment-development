// source/arrays_010.cpp
#include <iostream>
using namespace std;

int main() {
    int arr[] = {2, 6, 0, 1, 4};
    for (int i = 0; i < 5; i++) {
        cout << "arr[" << i << "] == " << *(arr + i) << endl;
    }
}