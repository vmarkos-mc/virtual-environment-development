// source/helloWorldUsingNS.cpp

#include <iostream> // Loads I/O functionality
using namespace std;

int main() { // Main signature (it returns an integer)
    cout << "Hello, world!\n"; // Prints to out stream
    return 0; // Mandatory, since main() returns an integer.
}