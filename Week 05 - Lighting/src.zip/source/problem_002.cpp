// source/problem_002.cpp
#include <iostream>
using namespace std;

double foo(int x) {
    return "f";
}

int main() {
    cout << foo(5) << endl;
}