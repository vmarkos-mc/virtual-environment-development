// source/stars_001.cpp
#include <iostream>
using namespace std;

int main() {
    double x; // declare a double varaible named x --> allocate 8 bytes of memory
    cout << "Enter a double: "; // print a message
    cin >> x; // read x from keyboard
    double *y = &x;
    /*
    y is a pointer of type double, i.e., y keeps the memory location of a variable that
    is of type "double". this is useful, since it informs the compiler about:
    * the size of the variable (8 bytes);
    * how to read those bytes to make sense of them.

    &x --> provides the memory location of the variable x

    *y --> dereferences the pointer y, i.e., it gets the value that is kept in the memory
           location stored in y.
    */
    cout << (*y == x) << endl;
}