// source/stars_005.cpp
#include <iostream>
using namespace std;

int main() {
    int x;
    cout << "Enter an int: ";
    cin >> x;
    int *ptrx = &x; // keep the memory location where x lives in
    (*ptrx)++;
    /*
    *ptrx --> dereference the pointer ptrx, i.e., get the value of x
    x++   --> roughly equivalent to x = x + 1;
    */
    cout << x << endl;  
}