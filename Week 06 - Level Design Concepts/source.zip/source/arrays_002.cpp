// source/arrays_002.cpp
#include <iostream>
using namespace std;

int main() {
    int arr1[5] = { 4, -2, 0, 4, 6 };
    int arr2[] = { 6, 5, 7, 9 };
    cout << "arr1[3] == " << arr1[3] << "\narr2[1] == " << arr2[1] << endl;
}