// source/arrays_005.cpp
#include <iostream>
using namespace std;

int main() {
    int arr[] = {2, 6, 5, 1};
    cout << (*arr)++ << endl;
    int* ptr = arr; // This stores `arr` as a pointer.
    // Actually, arrays **are** (const) pointers that point to the first memory
    // address of the first element of the array.
    ptr++; // Increment ptr by 4 bytes (sizeof(int)), so this points to the second
    // element of the array!
    cout << *ptr << endl; // This prints 6.
}