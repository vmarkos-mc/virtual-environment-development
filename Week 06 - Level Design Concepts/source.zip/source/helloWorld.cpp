// source/helloWorld.cpp

#include <iostream> // Loads I/O functionality

int main() { // Main signature (it returns an integer)
    std::cout << "Hello, world!\n"; // Prints to out stream
    return 0; // Mandatory, since main() returns an integer.
}