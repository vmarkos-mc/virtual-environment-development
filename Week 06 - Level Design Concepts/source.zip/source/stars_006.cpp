// source/stars_006.cpp
#include <iostream>
using namespace std;

int main() {
    int x, y;
    cout << "Enter two ints: ";
    cin >> x;
    cin >> y;
    int* ptrx = &x;
    int* ptry = &y;
    ptry = ptrx;
    (*ptrx)--;
    ptry = &y;
    cout << x << ", " << y << endl;
}

/*
State 0: After insertion (-line 9)
---------
| x | y |
---------

State 1: After pointer creation (-line 11)
-----------------
|   x   |   y   |
-----------------
    ^       ^
    |       |
-----------------
| ptrx  | ptry  |
-----------------

State 2: ptry = ptrx (line 12)
-----------------
|   x   |   y   |
-----------------
    ^________       
    |       |
-----------------
| ptrx  | ptry  |
-----------------

State 3: (*ptrx)-- (line 13)
-----------------
|  x--  |   y   |
-----------------
    ^________
    |       |
-----------------
| ptrx  | ptry  |
-----------------

State 4: ptry = &y (-line 14)
-----------------
|  x--  |   y   |
-----------------
    ^       ^
    |       |
-----------------
| ptrx  | ptry  |
-----------------
*/