#include <iostream>

using namespace std;

void alt() {
	int n;
	cout << "Please, enter an integer: ";
	cin >> n;
	if (n & 1) {
		cout << n << " is odd!" << endl;
	}
	else {
		cout << n << " is even!" << endl;
	}
}

int main() {
	// alt();
	int n;
	cout << "Please, enter an integer: ";
	cin >> n;
	if (n % 2 == 0) {
		cout << n << " is even!" << endl;
	} else {
		cout << n << " is odd!" << endl;
	}
}

/*
* ## Bitwise operations in C/C++
* When we write `n & 1`, which translates to the following (n == 3):
*	00000011 --> This is 3
* & 00000001 --> This is 1
* ----------
*   00000001 --> Bitwise 'and', i.e., 'and' each pair of bits separately.
* 
* For an even number this will be (n == 6)
*	00000110 --> This is 6
* & 00000001 --> This is 1
* ----------
*   00000000 --> Bitwise 'and', i.e., 'and' each pair of bits separately.
* 
* When we 'bitwise and' (`&`) with 1, the outcome will be either 1 or 0, 
* so either true or false (in humanese).
*/
