#include <iostream>

using namespace std;

int main() {
	unsigned int x = 4294967295; // This is 2^32 - 1, the largest unsigned int
	unsigned int y = x + 3;
	/*while (x * 2 != 0) {
		x = x * 2;
	}*/
	cout << x << " + 1 == " << y << endl;
}

/*
4294967295 = 2^32 - 1 == 11111111 11111111 11111111 11111111 in binary
So...
4294967295 + 1 == 1 00000000 00000000 00000000 00000000
But, we only have 4 bytes for each integer, so we drop 1, which means:
4294967295 + 1 == 00000000 00000000 00000000 00000000
4294967295 + 1 == 0

Now, if we used a typical (signed) integer (int), then, -1 is represented using 
2's complement:

1. First we write its absolute value in binary (1):

00000000 00000000 00000000 00000001

2. Then, we flip each bit:

11111111 11111111 11111111 11111110

3. Then we add 1:

	11111111 11111111 11111111 11111110
  +									  1
----------------------------------------
	11111111 11111111 11111111 11111111

So, when we write `int x = -1`, the computers memory looks like:

	11111111 11111111 11111111 11111111

But, this, as an unsigned integer is just:
	
	11111111 11111111 11111111 11111111 == 2^32 - 1 == 4294967295
*/