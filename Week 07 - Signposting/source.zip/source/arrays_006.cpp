// source/arrays_006.cpp
#include <iostream>
using namespace std;

int main() {
    int arr[] = { 2, 6, 5, 1 };
    float* ptr = (float*)arr;
    ptr++;
    cout << *ptr << endl;
}

/*
Chapter 1: What We Think Happens in RAM

0: Initially, somewhere in the computer's RAM:

|   2   |   6   |   5   |   1   | --> Contents
---------------------------------
|  100  |  104  |  108  |  112  | --> Memory addresses (in decimal)
    ^
   arr --> This is an int pointer

1: Then, we cast this to ptr, which is a float pointer:

|  2.0  |  6.0  |  5.0  |  1.0  | --> Contents
---------------------------------
|  100  |  104  |  108  |  112  | --> Memory addresses (in decimal)
    ^
   ptr --> This is a float pointer

2: ptr++:

|  2.0  |  6.0  |  5.0  |  1.0  | --> Contents
---------------------------------
|  100  |  104  |  108  |  112  | --> Memory addresses (in decimal)
            ^
           ptr --> This is still a float pointer

3: So, this should print 6.0.

Chapter 2: What Actually Happens in RAM

0: Initially, somewhere in the computer's RAM:

|   2   |   6   |   5   |   1   | --> Contents
---------------------------------
|  100  |  104  |  108  |  112  | --> Memory addresses (in decimal)
    ^
   arr --> This is an int pointer

But, we should better write this in bits:

| 00000000| 00000000| 00000000 | 00000010 | --> This is 2
-------------------------------------------
|   100   |   101   |   102    |   103    |

| 00000000| 00000000| 00000000 | 00000110 | --> This is 6
-------------------------------------------
|   104   |   105   |   106    |   107    |

| 00000000| 00000000| 00000000 | 00000101 | --> This is 5
-------------------------------------------
|   108   |   109   |   110    |   111    |

| 00000000| 00000000| 00000000 | 00000001 | --> This is 1
-------------------------------------------
|   112   |   113   |   114    |   115    |

1: Then, when we cast, this happens in RAM:

| 00000000| 00000000| 00000000 | 00000010 | --> This is a float (IEEE754)
-------------------------------------------
|   100   |   101   |   102    |   103    |

| 00000000| 00000000| 00000000 | 00000110 | --> This is a float (IEEE754)
-------------------------------------------
|   104   |   105   |   106    |   107    |

| 00000000| 00000000| 00000000 | 00000101 | --> This is a float (IEEE754)
-------------------------------------------
|   108   |   109   |   110    |   111    |

| 00000000| 00000000| 00000000 | 00000001 | --> This is a float (IEEE754)
-------------------------------------------
|   112   |   113   |   114    |   115    |

Just as a reminder, this:

00000000 00000000 00000000 00000110

as an integer, is 6.

In IEEE754 this is read as follows:

    exponent
    _________
0 | 0000000 0 | 0000000 00000000 00000110
^               ^^^^^^^ ^^^^^^^^ ^^^^^^^^
sign (+)                mantissa

So, this is actually, in binary:

1.00000000000000000000110 * 2^(-127)

which, in decimal, ir roughly: 8.40779 * 10^(-45)
*/