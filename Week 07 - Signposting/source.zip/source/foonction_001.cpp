// source/foonction_001.cpp
#include <iostream>
using namespace std;

int foo(int* arr, int arr_len) {
    // Some stuff here.
    for (int i = 0; i < arr.length)
}