#include <iostream>

using namespace std;

void dynamic_array(int size) {
	int* darr = (int*) malloc(size * sizeof(int)); // Memory allocation
	/* # Malloc
	* malloc allocates `size * sizeof(int)` memory addresses for us.
	* For instance, malloc(5) --> allocates 5 bytes of memory.
	* malloc() returns a `void*`, i.e., an "abstract" pointer, i.e., a pointer
	* that, roughly, points to no specific data type.
	* 
	* As a mental model, think of malloc(n) as follows:
	*	* Allocate n (consequtive) bytes.
	*	* Returns a pointer pointing to the first of those bytes.
	* So, we have to keep track of the output of malloc() to know where our bytes live
	* in.
	* 
	* In case of failure, malloc returns a NULL pointer!
	* Example: There might not be that much available memory to allocate!


	# Casting in C++:
	* When we want to make sure the output of a certain expression matches a 
	* given data type we can (try) to cast it to that target type.
	* 
	* For instance, to make sure the output of a division is integer, we can 
	* work as follows:
	* 
	* ```cpp
	* int x = (int) 5 / 2;
	* ```
	* 
	* ```cpp
	* char c = (char) 50 + 26; // This is \76, i.e., the ASCII character with code 76.
	* ```
	*/
	if (darr == NULL) { // In case of error, handle this by printing an error.
		// Think of NULL as Python's `None`.
		cerr << "Could not allocate memory!" << endl;
	}
	for (int i = 0; i < size; i++) { // Ask the user to provide all elements of darr.
		cout << "Please, enter an integer: ";
		cin >> *(darr + i); // This is darr[i].
	}
	cout << "[ ";
	for (int i = 0; i < size; i++) {
		cout << *(darr + i) << " ";
	}
	cout << "]" << endl;
	free(darr); // free() frees any memory allocated using malloc().
}

int main() {
	int size;
	cout << "Enter array size: ";
	cin >> size;
	dynamic_array(size);
	/*
	int arr[] = {5, 6, 8, 9, 1, 3};
	for (int i = 0; i < 6; i++) {
		cout << *(arr + i) << " @ " << (arr + i) << endl;
		// cout << arr[i] << " @ " << (arr + i) << endl; // This is equivalent to
		// the above
	}
	*/
	return 0;
}