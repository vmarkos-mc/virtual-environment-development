// source/problem_004.cpp
#include <iostream>
using namespace std;

void foo(int x) {
    return x + 4;
}

int main() {
    cout << foo(12) << endl;
}