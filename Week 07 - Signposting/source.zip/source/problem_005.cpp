// source/problem_005.cpp
#include <iostream>
using namespace std;

double foo(int x) {
    double y = x / 2;
    return y;
}

int main() {
    cout << foo(6.8) << endl;
}