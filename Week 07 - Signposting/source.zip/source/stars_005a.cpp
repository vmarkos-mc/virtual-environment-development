// source/stars_005a.cpp
#include <iostream>
using namespace std;

int main() {
    int x;
    cout << "Enter an int: ";
    cin >> x;
    int *ptrx = &x;
    cout << ptrx << endl;
    int y = (*ptrx++);
    cout << ptrx << endl;
    /*
    Assume x == 5;
    --- demystifying y = (*ptrx++) ---
    ptrx++ executes in the following way;
        * first, ptrx as is is used to perform any other operation required;
        * i.e., *ptrx is evaluated **first**, which means that *ptrx == 5;
        * then this value is stored at y, so y == 5;
        * at last, *ptrx is incremented by 1, so *ptrx is now 6;
        * but this change cannot be reflected anywhere, since there is no assignment to be made;
        * so x remains equal to 5.
    */
    auto z = (*++ptrx);
    cout << ptrx << endl;
    /*
    Assume x == 5;
    --- demystifying z = (*++ptrx) ---
    ++ptrx executes in the following way;
        * first, ptrx is modifier, incremented by '1' (4 bytes in this case);
        * then we dereference the pointer, obtaining the value of x, actually;
        * since x did not change before, it will not change now either.
    */
    cout << x << "\n" << y << "\n" << z << endl;
}