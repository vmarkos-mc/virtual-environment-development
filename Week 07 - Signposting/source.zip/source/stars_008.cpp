// source/stars_008.cpp
#include <iostream>
using namespace std;

int main() {
    int x, y;
    cout << "Enter two ints: ";
    cin >> x;
    cin >> y;
    const int* p1 = &x;
    int* const p2 = &y;
    // You code goes here...
    /*
    DISCLAIMER: In all cases, syntax makes more sense if read right to left!

    1. (*p1)++; --> Compilation time error, because p1 is defined as:
                    const int *, i.e., a pointer (*) that points to a 
                    const int. So, we cannot change the value kept at the
                    memory addressed pointed to by p1.
    2. (*p2)++; --> This runs properly because p2 has been defined as:
                    int* const, i.e., a const pointer to an integer.
    3. p1 = &y; --> This runs properly because p1 itself can change its 
                    value, i.e., where it points to.
    4. p2 = &x; --> Compilation time error, because p2 has been deined as:
                    int* const, i.e., a const pointer to an integer, so the
                    pointer itself cannot change.
    */
}