// source/strings_001.cpp
#include <iostream>
using namespace std;

int main() {
    char msg[] = { 'H', 'i', '!', '\0' };
    cout << msg << endl;
}