// source/strings_002.cpp
#include <iostream>
using namespace std;

int main() {
    char msg[] = "Hi!";
    cout << msg << endl;
}