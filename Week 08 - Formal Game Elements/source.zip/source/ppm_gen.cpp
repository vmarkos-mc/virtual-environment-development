#include <iostream> // This is used to print things on screen / streams
#include <fstream> // This is used to read from / write to files
#include <string> // To use strings
using namespace std;

int main() {
    // Image width and height in pixels
    int image_width = 256;
    int image_height = 256;

    // Render the image (into a file, eventually)
    string ppm_contents = "P3\n" + to_string(image_width) + ' ' + to_string(image_height) + "\n255\n";
    /* Format:

    ```ppm
    P3
    <width> <height>
    <max colors>
    ```
    
    In the above, width and height are the image width and height in pixels and <max colors> is the 
    maximum value for our RGB values within each pixel.
    */

    for (int i = 0; i < image_height; i++) {
        for (int j = 0; j < image_width; j++) {
            // RGB values as floats numbers in [0,1]
            float r = 0.0;
            float g = 0.0;
            float b = 1.0;

            // Integer RGB values, in {0,1,...,255}
            int ir = int(255 * r); // This might not always work as expected;
            int ig = int(255 * g); // This might not always work as expected;
            int ib = int(255 * b); // This might not always work as expected;

            ppm_contents += to_string(ir) + ' ' +  to_string(ig) +  ' ' + to_string(ib) + '\n';
        }
    }
    
    // Write the image string into a file
    string CWD = "C:\\Users\\MC\\Documents\\Courses\\Virtual Environment Development\\Week 10\\source";
    // string CWD = filesystem::();
    ofstream img_file; // Declare a file stream variable
    img_file.open(CWD + "sample_001.ppm", ios::out); // Open a file stream, i.e., open a file
    img_file << ppm_contents; // Write contents to the file
    img_file.close(); // Close the file
    /*
    `fstream` offers access to both `ofstream` (output) and `ifstream` (input).
    When we declare a stream as `ofstream` we can write to that file by default (`ios::out`)
    When we declare a stream as `ifstream` we can write to that file by default (`ios::in`)
    */
    return 0;
}