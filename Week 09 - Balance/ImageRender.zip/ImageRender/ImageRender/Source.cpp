#include <iostream> // This is used to print things on screen / streams
#include <fstream> // This is used to read from / write to files
#include <sstream> // This is used to use istringstream
#include <string> // To use strings
using namespace std;

int flipX(string filename, string flipped_filename) {
    ifstream img_file; // `ifstream` by default reads a file;
    img_file.open(filename, ios::in);
    int i = 0; // This is a line counter
    int j = 0;
    string line; // This will keep each line of the file
    string ppm_header; 
    int image_width, image_heigth;
    int max_color;
    int r, g, b;
    ofstream flipped_img_file; // This is where the flipped image will live in
    flipped_img_file.open(flipped_filename, ios::out);
    int* img_pixels = nullptr;
    while (getline(img_file, line)) {
        istringstream iss(line);
        if (i == 0) {
            iss >> ppm_header; // Read the image header (P3)
            flipped_img_file << ppm_header << '\n'; // Write it to the output file
        }
        else if (i == 1) {
            iss >> image_width >> image_heigth; // Read source width / height
            flipped_img_file << image_width << ' ' << image_heigth << '\n'; // Write width / height
            img_pixels = new int[image_width * image_heigth * 3]; // Allocates sizeof(int) * [...] bytes of memory
            // Our image contains `image_width * image_heigth` pixels and each pixel
            // comprises of 3 integers;
        }
        else if (i == 2) {
            iss >> max_color;
            flipped_img_file << max_color << '\n';
        }
        else {
            iss >> r >> g >> b;
            // Store those values somewhere...
            *(img_pixels + j++) = r;
            *(img_pixels + j++) = g;
            *(img_pixels + j++) = b;
        }
        i++;
    }
    img_file.close();
    int index;
    for (int i = image_heigth - 1; i >= 0; i--) { // Parse lines bottom to top...
        for (int j = 0; j < image_width * 3; j += 3) { // Parse each line left to right...
            // Move by a step of 3, since each pixel is mapped to 3 values!
            index = i * image_width * 3 + j; // Get the actual index in img_pixels
            r = *(img_pixels + index);
            g = *(img_pixels + index + 1);
            b = *(img_pixels + index + 2);
            flipped_img_file << r << ' ' << g << ' ' << b << '\n';
        }
    }
    delete img_pixels;
    flipped_img_file.close();
    return 0;
}

int init_sample_img() {
    // Image width and height in pixels
    int image_width = 256;
    int image_height = 256;

    ofstream img_file; // Declare a file stream variable
    img_file.open("sample_001.ppm", ios::out); // Open a file stream, i.e., open a file

    // Render the image (into a file, eventually)
    // String variant, keep the entire image string into memory and then write once.
    // string ppm_contents = "P3\n" + to_string(image_width) + ' ' + to_string(image_height) + "\n255\n";
    // File stream version, keep the file open and stream contents into it.
    img_file << "P3\n" << image_width << ' ' << image_height << "\n255\n";
    /* Format:

    ```ppm
    P3
    <width> <height>
    <max colors>
    ```

    In the above, width and height are the image width and height in pixels and <max colors> is the
    maximum value for our RGB values within each pixel.
    */

    for (int i = 0; i < image_height; i++) {
        for (int j = 0; j < image_width; j++) {
            // RGB values as floats numbers in [0,1]
            double r = 0.0;
            double g = double(i) / (image_height - 1); // `-1` since i <- {0,1,...,255}
            double b = double(j) / (image_width - 1);
            /*
            * Rescaling to 255 * 255:
            * Assume you have an image with dimensions 1080 * 1080.
            * Then, i, j might range in {0,1,...,1079}.
            * To rescale them to an integer in {0,1,...,255} we can work as follows:
            *   1. Divide i by 1079, so i / 1079 is a float in [0,1]
            *   2. Multiply by 255, so int(i / 1079 * 255) is an int in {0,...,255}
            */

            // Integer RGB values, in {0,1,...,255}
            int ir = int(255.999 * r);
            int ig = int(255.999 * g);
            int ib = int(255.999 * b);

            /*
            * Old version:
            * 
            * ```cpp
            * int ir = int(255 * r); // This might not always work as expected;
            * int ig = int(255 * g); // This might not always work as expected;
            * int ib = int(255 * b); // This might not always work as expected;
            * ```
            * 
            * In the above, the only case a pixel gets 255 in some colour is if
            * `r` or `g` or `b` is exactly `1.0`. For all other values in {0,1,...,254}
            * we have more than one values of `r`, `g`, `b` where they might appear.
            * For example, for `r == 0.0`, then `ir == int(255 * 0) == 0`.
            * However, also for `r == 0.0038`, then `ir == int(255 * 0.0038) == 0`.
            */

            img_file << ir << ' ' << ig << ' ' << ib << '\n';
        }
    }

    // Write the image string into a file
    // string CWD = "C:\\Users\\MC\\Documents\\Courses\\Virtual Environment Development\\Week 10\\source";
    // string CWD = filesystem::();
    // ofstream img_file; // Declare a file stream variable
    // img_file.open("sample_001.ppm", ios::out); // Open a file stream, i.e., open a file
    // img_file << ppm_contents; // Write contents to the file
    img_file.close(); // Close the file
    /*
    `fstream` offers access to both `ofstream` (output) and `ifstream` (input).
    When we declare a stream as `ofstream` we can write to that file by default (`ios::out`)
    When we declare a stream as `ifstream` we can write to that file by default (`ios::in`)
    */
    return 0;
}

int main() {
    int exit_code = flipX("sample_001.ppm", "x_flipped_sampled_001.ppm");
    cout << "Process 'flipX()' exited with exit code " << exit_code << endl;
}